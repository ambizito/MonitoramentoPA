import os
import shutil
import threading
from datetime import datetime, timedelta

# Função para gerar a senha baseada no padrão
def generate_password(name):
    return f"V4m0sViverNossosSonhos#{name}@"

# Configurações de máquinas e diretórios
machines = [
    {"ip": "192.168.20.101", "name": "Berners"},
    {"ip": "192.168.20.102", "name": "Gates"},
    {"ip": "192.168.40.101", "name": "Bezos"},
    {"ip": "192.168.40.102", "name": "Mark"},
    {"ip": "192.168.40.107", "name": "Turing"},
    {"ip": "192.168.30.102", "name": "Jobs"},
    {"ip": "192.168.30.101", "name": "Linus"},
    {"ip": "192.168.30.109", "name": "Robos"},
    {"ip": "192.168.30.103", "name": "Extra"}
]

# Usuário padrão para todas as máquinas
username = "administrator"

# Tempo limite para considerar arquivos novos
time_threshold = datetime.now() - timedelta(minutes=10)

# Diretório base onde os logs serão salvos
base_local_path = r"C:\ServerLogs"


# Função para verificar se o caminho remoto está acessível
def is_remote_path_accessible(remote_path):
    print(f"Verificando acesso ao caminho remoto: {remote_path}")
    try:
        if os.path.exists(remote_path):
            print(f"Acesso ao caminho remoto {remote_path} confirmado.")
            return True
        else:
            print(f"O caminho remoto {remote_path} não está acessível.")
            return False
    except Exception as e:
        print(f"Erro ao verificar o caminho remoto {remote_path}: {e}")
        return False


# Função para copiar arquivos de uma máquina específica
def copy_file(remote_file, local_file):
    try:
        shutil.copy(remote_file, local_file)
        print(f"Arquivo copiado: {remote_file}")
    except Exception as e:
        print(f"Erro ao copiar {remote_file}: {e}")


# Função principal para processar uma máquina
def process_machine(machine):
    threads = []
    remote_path = rf"\\{machine['ip']}\logs"  # Caminho remoto baseado no IP
    local_path = os.path.join(base_local_path, machine["name"])  # Pasta baseada no nome da máquina

    # Gerar senha
    password = generate_password(machine["name"])

    # Verifica se o caminho remoto está acessível
    if is_remote_path_accessible(remote_path):
        print(f"Acessando o diretório remoto da máquina {machine['name']} ({machine['ip']}): {remote_path}")

        # Cria o diretório local se não existir
        if not os.path.exists(local_path):
            os.makedirs(local_path)

        # Itera sobre os arquivos no diretório remoto
        for file_name in os.listdir(remote_path):
            remote_file = os.path.join(remote_path, file_name)
            local_file = os.path.join(local_path, file_name)

            # Ignora subdiretórios
            if not os.path.isfile(remote_file):
                continue

            # Verifica a data de modificação do arquivo
            file_mod_time = datetime.fromtimestamp(os.path.getmtime(remote_file))
            if file_mod_time < time_threshold:
                # Cria uma thread para copiar o arquivo
                thread = threading.Thread(target=copy_file, args=(remote_file, local_file))
                threads.append(thread)
                thread.start()

        # Aguarda todas as threads terminarem
        for thread in threads:
            thread.join()

        print(f"Cópia concluída para a máquina: {machine['name']} ({machine['ip']})")
    else:
        print(f"Não foi possível acessar o diretório remoto da máquina {machine['name']} ({machine['ip']}).")


# Processa cada máquina na lista
for machine in machines:
    print(f"Verificando a máquina: {machine['name']} ({machine['ip']})")
    remote_path = rf"\\{machine['ip']}\logs"
    if is_remote_path_accessible(remote_path):
        proceed = input(f"Deseja continuar o processamento para {machine['name']}? (s/n): ").strip().lower()
        if proceed == 's':
            process_machine(machine)
        else:
            print(f"Processamento para {machine['name']} foi ignorado.")
    else:
        print(f"Falha ao acessar o caminho remoto para {machine['name']} ({machine['ip']}).")

print("Processamento concluído para todas as máquinas.")
